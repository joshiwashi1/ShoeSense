package com.shoesense.shoesense.welcome

interface WelcomeView {
    fun navigateToRegister()
    fun navigateToLogin()
}
