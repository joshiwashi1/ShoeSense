package com.shoesense.shoesense.register

interface RegisterView {
    fun showError(message: String)
    fun showSuccess(message: String)
}
