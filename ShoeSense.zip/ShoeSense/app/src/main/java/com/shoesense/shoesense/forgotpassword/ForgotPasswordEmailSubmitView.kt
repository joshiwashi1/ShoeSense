package com.shoesense.shoesense.forgotpassword

interface ForgotPasswordEmailSubmitView {
    fun closeScreen()
    fun showResendMessage()
}
